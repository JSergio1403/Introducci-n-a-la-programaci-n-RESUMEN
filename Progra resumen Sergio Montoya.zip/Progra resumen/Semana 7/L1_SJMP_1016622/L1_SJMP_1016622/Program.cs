﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_SJMP_1016622
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);

            //La diferencia es que writeline escribe por parrafos, cuando write solamente escribe en la misma linea
            Console.Write("Hola Mundo");
            Console.Write("soy " + Nombre);
            Console.ReadKey();
        }
    }
}
